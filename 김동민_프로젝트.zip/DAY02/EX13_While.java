package DAY02;

public class EX13_While {

	public static void main(String[] args) {
		// 1~10까지 공백을 두고 출력하시오.
		int a = 1;
		
		//while( 조건 ) { 반복 실행문 }
		while( a <= 10 ) {
			System.out.println(a);
			a++;
		}
	}
}
