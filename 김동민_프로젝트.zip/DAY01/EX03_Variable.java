package DAY01;

public class EX03_Variable {
	
	public static void main(String[] args) {
		int x; // int형 변수 x 선언
		int y; // int형 변수 y선언
		// 한줄 복사 : ctrl + alt + (↑,↓)
		
		// = (대입연산자)
		// A = B : B라는 값을 변수 A에 대입하는 연산자
		
		x = 10;// 변수 x에 10대입
		y = 20;// 변수 y에 20대입
		
		// x + y
		// 피연산자 	: x, y
		// 연산자 	: +
		
		// sysout : ctrl + space
		System.out.println("x : " + x);
		System.out.println("y : " + y);
		System.out.println("x + y = "+ (x+y));
		System.out.println("(x + y) / 2 = "+ (x+y)/2);
		System.out.println("x * y = "+ x*y);
		
	}
	
}
